from sqlalchemy import Column, Integer, String, ForeignKey
from database import Base

class Industry(Base):
    __tablename__ = "industries"

    id = Column(Integer, primary_key=True, index=True)
    industry_name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    parent_id = Column(Integer, ForeignKey("industries.id"))
